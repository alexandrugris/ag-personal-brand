---
name: ag-trenches-style
description: |
  Produce stylish texts, presentations, PDF documents and web pages in the AG
  "From The Trenches" visual system — warm paper, warm ink, one burgundy accent,
  Georgia serif for voice and Inter for metadata. Load this skill when the user
  asks to write, rewrite or copy-edit an article, essay or note in this style;
  to build or restyle a slide deck, PDF document, report, CV or landing page;
  or to apply, extend or re-skin the AG Style design system itself. Triggers on
  "in my style", "AG Style", "From The Trenches", "style like alexandrugris",
  "make this look polished", "minimal and refined", "deck", "slides",
  "one-pager", "style guide", "color palette". Do NOT use for unrelated
  corporate brand guidelines, or for plain text edits with no visual deliverable.
---

# AG Style — "From The Trenches"

A four-surface visual system distilled from `alexandrugris.ro` (editorial,
current) and `alexandrugris.github.io` (paper-like blog, older). Both sites
share the spine: warm paper, warm ink, one burgundy accent, serif for voice and
sans for metadata, hairline rules, generous space.

Canonical assets:

| Path | Use |
|---|---|
| `references/tokens.css` | Single source of truth: palette, type scale, components, print rules |
| `references/style-spec.md` | Full written spec, per-medium rules, anti-patterns |
| `templates/page.html` | Working web page (masthead, hero, principles, writings, about, footer) |
| `templates/document.html` | Working A4 document (fixed-height pages, running footer, figure, table) |
| `scripts/render.py` | HTML → PDF (+ page PNGs), inlines `tokens.css` automatically |
| `scripts/shoot.py` | HTML → PNG screenshot (page or viewport) |
| `scripts/deck_shots.py` | PPTX → per-slide PNGs (via soffice + pdftoppm) |
| `scripts/build_deck.py` | Builds the reference 9-slide 16:9 deck from primitives |

## Inputs to collect

- **Medium**: web page, document/PDF, slides, or long-form text. Changes the
  layout rules; the palette and type system do not change.
- **Content**: what the piece says. If the user only says "make it look like
  my site", write the content yourself in the voice below and say you did.
- **Length**: one page or many. Documents are fixed-height A4 pages — ask how
  many, or default to 3.
- Do not ask about colours, fonts or spacing. Those are decided.

## Procedure

1. **Read `references/style-spec.md` first** if the medium is new to you. It
   holds the rules; this file holds the workflow.

2. **Start from the canonical tokens.** Never hand-pick a colour, size or
   spacing value. Use `references/tokens.css` — it is the only place colours
   live. If you need a value that is not there, add it to `tokens.css` and
   reference it, so the system stays single-sourced.

3. **Pick the medium and use its template.**
   - Web → `templates/page.html`, keep `TOKENS_PATH` in the `<link>`;
     `scripts/render.py` inlines it.
   - Document → `templates/document.html`. Pages are fixed-height
     (`width:210mm; height:297mm; overflow:hidden`), so **content that
     overflows is silently clipped** — check the rendered PNGs every time and
     trim copy, never shrink type below 10.5pt.
   - Slides → `scripts/build_deck.py`. Edit the content lists inside `build()`
     rather than starting a new file, so the deck keeps the system.
   - Long-form text → no template; apply the typography and voice rules in
     Markdown.

   Every document template must keep `class="doc"` on `<body>` — that class is
   what activates the print type scale in `tokens.css`. Without it the document
   silently renders at web scale.

4. **Write the copy in the AG voice** (see `references/style-spec.md` §6):
   declarative not promotional, concrete nouns over abstractions, past tense for
   experience and present for principles, sentence-case headings. Avoid
   leverage/synergy/robust/journey/unlock.

5. **Render and inspect.** Never ship a PDF or deck you have not looked at:
   ```bash
   python3 scripts/render.py doc.html out.pdf --png-dir shots/ --no-footer
   python3 scripts/shoot.py page.html shots/page.png --full
   python3 scripts/deck_shots.py deck.pptx shots/
   ```
   Check for: text colliding with the running footer, clipped text on a fixed
   page, an orphan heading, two accents in one visual block.

6. **Deliver the artefact plus its screenshots.** A style the user cannot see is
   not delivered — always include rendered images of at least the first page and
   one interior page or slide.

## Output contract

- A file deliverable (`.pdf`, `.pptx`, `.html`) in the requested medium, plus
  rendered PNGs of it.
- If the user asked for new content, the content is written in the AG voice and
  clearly original — do not paste text from the live sites.
- If the user asked to restyle *their* content, keep their words; change only
  structure and presentation.

## Failure handling

- **Text overflows a fixed page**: cut copy, split into another page, or reduce
  a figure. Never reduce body type below 10.5pt and never let `overflow:hidden`
  crop a sentence silently.
- **Georgia is usually not installed**: the CSS stack falls back to Gelasio,
  which is metric-compatible, so layout does not shift. Install Gelasio
  (`font-weight` 700 must map to `Gelasio-Bold`, not a synthetic bold) and
  alias `Georgia → Gelasio` in `~/.config/fontconfig/fonts.conf`.
- **`--no-footer` for `render.py`**: document templates carry their own running
  footer with a hard-coded page number. Without the flag you get a second,
  duplicated footer.
- **Name collisions**: `soffice --convert-to pdf` writes `<stem>.pdf` and will
  overwrite a document PDF that shares the stem. Use `scripts/deck_shots.py`,
  which converts in a temp directory.
- **Chromium missing** for `render.py`/`shoot.py`: the script looks in
  `/root/.cache/ms-playwright` and `~/.cache/ms-playwright`. If neither exists,
  fall back to `soffice --headless --convert-to pdf` for decks and report that
  the PDF path was not used.
- **Georgia missing** on the target machine: the CSS stack falls back to
  Gelasio, which is metric-compatible. Install it rather than letting the page
  fall back to Times.
- **PPTX opened elsewhere without Gelasio/Inter**: Georgia and Inter are the
  declared fonts, so the file stays correct on any machine with them; render
  previews with the bundled script instead of trusting PowerPoint.
- Unsure which medium the user means: ask once, offering web / document /
  slides, and proceed on the reply.

## Examples

**Input** — "Turn this outline into a 3-page PDF in my style."
**Output** — `templates/document.html` filled with the outline, rendered via
`scripts/render.py` to a 3-page A4 PDF with `sample-document-1.png` …
`-3.png` attached.

**Input** — "Build me a deck about the principles."
**Output** — `scripts/build_deck.py` edited with the new content, producing a
9-slide 16:9 PPTX, then `scripts/deck_shots.py` for a PNG of every slide.

**Input** — "Make my homepage look like alexandrugris.ro."
**Output** — `templates/page.html` as the base: keep the masthead, hero with
the copy card, 4-column principle grid, 1.16/1/1 writings grid and the
`.8/1.2` about band; replace only the content.
